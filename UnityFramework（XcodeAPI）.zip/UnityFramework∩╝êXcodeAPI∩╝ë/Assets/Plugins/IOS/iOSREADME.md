为兼容C++.mm文件，需要设置每个.m类的Target Membership为UnityFramework

为兼容JSONModel报错Cannot use '@try' with Objective-C exceptions disable等问题需要如下设置：
Targets -> UnityFramework -> Build Settings(All - Combined)
Enable Objective-C Exceptions  YES
