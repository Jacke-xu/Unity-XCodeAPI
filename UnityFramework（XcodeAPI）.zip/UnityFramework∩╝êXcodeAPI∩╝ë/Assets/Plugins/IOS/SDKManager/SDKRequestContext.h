//
//  SDKRequestContext.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import <Foundation/Foundation.h>
#import "SDKRequest.h"
#import "SDKResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SDKRequestContext <TRequest: id<SDKRequestProtocol>, TResponse: id<SDKResponseProtocol>> : NSObject

/**
 *  Unity端的请求数据
 */
@property (nonatomic, strong) SDKRequest *request;

/**
 *  iOS响应Unity(请求成功时调用此方法回复Unity)
 *
 *  @param response 回复Unity的SDKResponse对象
 */
- (void)setResponse:(SDKResponse *_Nullable)response;

/**
 *  iOS响应Unity(请求失败时调用此方法回复Unity)
 *
 *  @param eventId 回复Unity的eventId
 *
 *  @param data 回复Unity的data消息
 */
+ (void)responseUnityWithEventId:(NSString *_Nullable)eventId data:(NSString *_Nullable)data;

@end

NS_ASSUME_NONNULL_END
