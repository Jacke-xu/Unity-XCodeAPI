//
//  SDKReflection.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SDKReflection : NSObject

/**
 *  根据传入的superClass获取对应的子类
 *
 *  @param superClass 父类
 *
 *  @return 获取到的继承自superClass的子类
 */
+ (NSArray <NSString *>*)sharedSubClassFrom:(Class _Nullable)superClass;

/**
 *  根据传入的className获取对应的方法列表
 *
 *  @param className 类名
 *
 *  @return 获取到的className类中的所有方法
 */
+ (NSArray <NSString *>*_Nullable)sharedClassMethodFrom:(NSString *_Nullable)className;

/**
 *  字典转JSON格式字符串
 *
 *  @param dictionary 要转换成JSON的字典
 *
 *  @return 获取到的JSON字符串
 */
+ (NSString *_Nullable)dictionaryToJson:(NSDictionary *_Nullable)dictionary;

/**
 *  JSON格式字符串转字典
 *
 *  @param json 要转换成字典的JSON格式字符串
 *
 *  @return 获取到的字典
 */
+ (NSDictionary *_Nullable)jsonToDictionary:(NSString *_Nullable)json;

/**
 *  根据传入的对象获取对象内部的属性
 *
 *  @param model 要获取属性的model
 *
 *  @return 获取到的对象内部的属性(不包含父类属性)
 */
+ (NSArray <NSString *> *_Nullable)sharedJsonDataKeys:(id _Nullable)model;

@end

NS_ASSUME_NONNULL_END
