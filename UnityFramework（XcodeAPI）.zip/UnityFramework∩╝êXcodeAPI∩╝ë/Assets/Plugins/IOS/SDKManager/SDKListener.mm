//
//  SDKListener.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import "SDKListener.h"
#import "SDKProtoManager.h"
#import "SDKMoudleManager.h"
#import "MacroDefinition.h"

@implementation SDKListener

/**
 *  应用程序入口
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary<UIApplicationLaunchOptionsKey,id> *)launchOptions {
    [super application:application didFinishLaunchingWithOptions:launchOptions];
    
    // 初始化SDKMoudleManager
    [SDKMoudleManager initialization];
    
    return YES;
}

/**
 *  应用程序将要退出
 */
- (void)applicationWillTerminate:(UIApplication *)application {
    NSLog(@"应用程序将要退出");
    [SDKMoudleManager releaseAll];
}

/**
 *  应用程序将要进入前台活动
 */
- (void)applicationWillEnterForeground:(UIApplication *)application {
    NSLog(@"应用程序将要进入前台活动");
}

/**
 *  应用程序进入后台活动
 */
- (void)applicationDidEnterBackground:(UIApplication *)application {
    NSLog(@"应用程序进入后台活动");
}

/**
 *  应用程序将要变为非活跃状态
 */
- (void)applicationWillResignActive:(UIApplication *)application {
    NSLog(@"应用程序将要变为非活跃状态");
}

/**
 *  应用程序已注册远程通知
 */
- (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSNotification*)notification {
    NSLog(@"应用程序已注册远程通知");
}

/**
 *  应用程序注册远程通知出错
 */
- (void)didFailToRegisterForRemoteNotificationsWithError:(NSNotification*)notification {
    NSLog(@"应用程序注册远程通知出错");
}

/**
 *  应用程序接收到远程通知
 */
- (void)didReceiveRemoteNotification:(NSNotification*)notification {
    NSLog(@"应用程序接收到远程通知");
}

/**
 *  应用程序接收到本地通知
 */
- (void)didReceiveLocalNotification:(NSNotification*)notification {
    NSLog(@"应用程序接收到本地通知");
}

/**
 *  接收到来自Unity的消息
 */
extern "C" void CallSync(const char *interfaceName, const char *data) {
    NSLog(@"iOS收到Unity消息\ninterfaceName = %s\ndata = %s",interfaceName, data);
    [SDKProtoManager invoke:[[NSString alloc]initWithUTF8String:interfaceName] data:[[NSString alloc]initWithUTF8String:data]];
}

@end
