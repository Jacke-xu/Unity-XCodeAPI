//
//  MacroDefinition.h
//  WYBasisKit
//
//  Created by jacke－xu on 16/9/4.
//  Copyright © 2016年 jacke-xu. All rights reserved.
//

#import <Availability.h>

#ifdef __OBJC__

#ifndef MacroDefinition_h
#define MacroDefinition_h

///block self
#define wy_weakSelf(type)      __weak typeof(type) weak##type = type;
#define wy_strongSelf(type)    __strong typeof(type) type = weak##type;

//G－C－D
///在子线程上运行的GCD
#define WY_GCD_SubThread(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), block)

///在主线程上运行的GCD
#define WY_GCD_MainThread(block) dispatch_async(dispatch_get_main_queue(),block)

///只运行一次的GCD
#define WY__GCD_OnceThread(block) static dispatch_once_t onceToken; dispatch_once(&onceToken, block);

///DEBUG打印日志
//#ifdef DEBUG
# define NSLog(FORMAT, ...) printf("[%s 行号:%d]:\n%s\n\n\n\n",__FUNCTION__,__LINE__,[[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String])
//#else
//# define NSLog(FORMAT, ...)
//#endif

///获取app包路径
#define wy_bundlePath     [[NSBundle mainBundle] bundlePath];

///获取app资源目录路径
#define wy_appResourcePath         [[NSBundle mainBundle] resourcePath];

///获取app包的readme.txt文件
#define wy_readmePath         [[NSBundle mainBundle] pathForResource:@"readme" ofType:@"txt"];

///app名字
#define wy_appName          [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleName"]

#define wy_appStoreName     [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"]

///应用标识
#define wy_appIdentifier    [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];

///应用商店版本号
#define wy_appStoreVersion   [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

///应用构建版本号
#define wy_appBuildVersion        [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]


#endif /* MacroDefinition_h */

#endif /* OBJC */
