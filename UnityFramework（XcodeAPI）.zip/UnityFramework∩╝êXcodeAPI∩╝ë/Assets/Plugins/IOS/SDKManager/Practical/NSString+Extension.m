//
//  NSString+Extension.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/6.
//

#import "NSString+Extension.h"

@implementation NSString (Extension)

+ (NSString *)emptyStr:(NSString *)string {
    
    if(([string isKindOfClass:[NSNull class]]) || ([string isEqual:[NSNull null]]) || (string == nil) || (!string) || (string.length <= 0)) {
        
        string = @"";
    }
    return string;
}

+ (BOOL)isEmptyStr:(NSString *)string {
    
    if(([string isKindOfClass:[NSNull class]]) || ([string isEqual:[NSNull null]]) || (string == nil) || (!string) || (string.length <= 0)) {
        
        return YES;
    }
    
    return NO;
}

@end
