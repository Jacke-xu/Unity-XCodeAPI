//
//  NSString+Extension.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Extension)

/**
 *  获取非空字符串
 */
+ (NSString *)emptyStr:(NSString *)string;

/**
 *  是否是空字符串
 */
+ (BOOL)isEmptyStr:(NSString *)string;


@end

NS_ASSUME_NONNULL_END
