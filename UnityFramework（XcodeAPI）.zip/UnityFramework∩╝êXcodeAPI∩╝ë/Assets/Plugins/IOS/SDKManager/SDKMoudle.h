//
//  SDKMoudle.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SDKMoudle : NSObject

/**
 *  初始化SDKMoudle子类(子类重写该方法定义具体实现)
 */
- (void)initialization;

/**
 *  SDKMoudle子类对应的唯一标识
 */
@property (nonatomic, copy) NSString *identifier;

/**
 *  释放SDKMoudle对应子类绑定的所有协议
 */
- (void)releaseAll;


@end

NS_ASSUME_NONNULL_END
