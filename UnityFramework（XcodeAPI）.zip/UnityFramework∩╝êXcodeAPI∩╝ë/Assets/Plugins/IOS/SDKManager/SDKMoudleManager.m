//
//  SDKMoudleManager.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/6.
//

#import "SDKMoudleManager.h"
#import "SDKMoudle.h"
#import "SDKReflection.h"

@interface SDKMoudleManager()

/**
 *  存放所有的SDKMoudle
 */
@property (nonatomic, strong) NSMutableDictionary <NSString *, id>*sdkMoudles;

@end

@implementation SDKMoudleManager
singletonForImplementation(SDKMoudleManager)

- (instancetype)init {
    if (self == [super init]) {
        if (_sdkMoudles == nil) {
            _sdkMoudles = [NSMutableDictionary dictionary];
        }
    }
    return self;
}

+ (void)initialization {
    [self handleRegisterClass];
}

+ (id)getMoudleWithIdentifier:(NSString *)identifier {
    return [[SDKMoudleManager shared].sdkMoudles.allKeys containsObject:identifier] ? [[SDKMoudleManager shared].sdkMoudles objectForKey:identifier] : nil;
}

/**
 *  获取并添加需要注册的SDKMoudle子类
 */
+ (void)handleRegisterClass {
    
    for (NSString *className in [SDKReflection sharedSubClassFrom:[SDKMoudle class]]) {
        if ([[SDKMoudleManager shared].sdkMoudles.allKeys containsObject:className]) {
            continue;
        }
        Class class = NSClassFromString(className);
        SDKMoudle *subMoudle = [[class alloc] init];
        [subMoudle setValue:className forKey:@"identifier"];
        [subMoudle initialization];
        [[SDKMoudleManager shared].sdkMoudles setValue:subMoudle forKey:className];
    }
}

+ (void)releaseAll {
    
    for (id subMoudle in [SDKMoudleManager shared].sdkMoudles) {
        [subMoudle releaseAll];
    }
    [[SDKMoudleManager shared].sdkMoudles removeAllObjects];
    [SDKMoudleManager shared].sdkMoudles = nil;
}

@end
