//
//  SDKListener.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import "UnityAppController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SDKListener : UnityAppController

@end
IMPL_APP_CONTROLLER_SUBCLASS (SDKListener)

NS_ASSUME_NONNULL_END
