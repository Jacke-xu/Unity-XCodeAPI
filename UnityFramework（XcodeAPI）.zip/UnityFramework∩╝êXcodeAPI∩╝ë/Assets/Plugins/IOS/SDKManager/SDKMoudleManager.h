//
//  SDKMoudleManager.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/6.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"
@class SDKMoudle;

NS_ASSUME_NONNULL_BEGIN

@interface SDKMoudleManager : NSObject
singletonForInterface(SDKMoudleManager)

/**
 *  初始化SDKMoudleManager
 */
+ (void)initialization;

/**
 *  根据传入的identifier获取对应的继承至SDKMoudle的对象(注意，如果传入有误或者不存在对应的SDKMoudle子类则会返回一个nil)
 *
 *  @param identifier SDKMoudle子类对应的唯一标识
 *
 *  @return 获取到的继承自SDKMoudle的子类对象
 */
+ (id)getMoudleWithIdentifier:(NSString *_Nullable)identifier;

/**
 *  释放所有SDKMoudle子类
 */
+ (void)releaseAll;

@end

NS_ASSUME_NONNULL_END
