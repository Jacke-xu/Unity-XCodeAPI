//
//  SDKRequestContext.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import "SDKRequestContext.h"
#import "MacroDefinition.h"

@implementation SDKRequestContext

- (void)setResponse:(SDKResponse *)response {
    [[self class] responseUnityWithEventId:_request.eventId data:[response toJSONString]];
}

+ (void)responseUnityWithEventId:(NSString *)eventId data:(NSString *)data {
    
    const char *gameObjectName = [@"SDKManager" UTF8String];
    const char *methodName = [@"OnPlatformCall" UTF8String];
    
    // 拼接返回给unity的消息
    const char *message = [[NSString stringWithFormat:@"%@:%@",eventId, data] UTF8String];

    UnitySendMessage(gameObjectName, methodName, message);
    
    NSLog(@"iOS回复Unity\n%s",message);
}

@end
