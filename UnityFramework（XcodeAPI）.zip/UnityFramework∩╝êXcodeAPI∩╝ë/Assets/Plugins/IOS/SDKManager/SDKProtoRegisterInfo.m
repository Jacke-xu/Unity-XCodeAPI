//
//  SDKProtoRegisterInfo.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/9.
//

#import "SDKProtoRegisterInfo.h"
#import "SDKRequestContext.h"
#import "SDKMoudleManager.h"
#import "SDKMoudle.h"

@interface SDKProtoRegisterInfo()

@property (nonatomic, strong) SDKRequestContext *requestContext;

@end

@implementation SDKProtoRegisterInfo

- (instancetype)initWithInterfaceName:(NSString *)interfaceName method:(NSString *)method moudle:(SDKMoudle *)subMoudle requestClass:(NSString *)requestClass responseClass:(NSString *)responseClass {
    
    if (self == [super init]) {
        _interfaceName = interfaceName;
        _method = method;
        _subMoudle = subMoudle;
        _requestClass = requestClass;
        _responseClass = responseClass;
    }
    return self;
}

- (void)callMoudleMethod:(SDKRequestContext *)requestContext {
    
    _requestContext = requestContext;
    
    // 调用SDKMoudle子类中的方法
    SEL selector = NSSelectorFromString(_method);
    IMP imp = [_subMoudle methodForSelector:selector];
    void(*function)(id, SEL, SDKRequestContext *) = (void *)imp;
    function(_subMoudle, selector, requestContext);
}

@end
