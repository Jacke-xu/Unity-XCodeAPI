//
//  SDKMoudle.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/6.
//

#import "SDKMoudle.h"
#import "SDKProtoManager.h"

@implementation SDKMoudle

- (void)initialization {}

- (void)releaseAll {
    [SDKProtoManager releaseAll];
}

@end
