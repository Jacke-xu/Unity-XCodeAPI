//
//  SDKRequest.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import <Foundation/Foundation.h>
#import "JSONModelLib.h"

NS_ASSUME_NONNULL_BEGIN

@protocol SDKRequestProtocol <NSObject>
@end
@interface SDKRequest : JSONModel<SDKRequestProtocol>

/**
 *  unity传过来的请求事件ID
 */
@property (nonatomic, copy) NSString <Optional>*eventId;

@end

NS_ASSUME_NONNULL_END
