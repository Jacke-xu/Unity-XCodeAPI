//
//  SDKProtoRegisterInfo.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/9.
//

#import <Foundation/Foundation.h>
#import "SDKRequestContext.h"
@class SDKMoudle;

NS_ASSUME_NONNULL_BEGIN

@interface SDKProtoRegisterInfo : JSONModel

/**
 *  Unity调用方法对应的SDKMoudle子类对象
 */
@property (nonatomic, copy, readonly) SDKMoudle *subMoudle;

/**
 *  Unity调用方法对应的SDKRequest子类名
 */
@property (nonatomic, copy, readonly) NSString *requestClass;

/**
 *  Unity调用方法对应的SDKResponse子类名
 */
@property (nonatomic, copy, readonly) NSString *responseClass;

/**
 *  Unity调用方法对应的interfaceName
 */
@property (nonatomic, copy, readonly) NSString *interfaceName;

/**
 *  key对应的方法名
 */
@property (nonatomic, copy, readonly) NSString *method;

/**
 *  唯一初始化方法
 *
 *  @param interfaceName Unity调用方法对应的interfaceName
 *
 *  @param method key对应的方法名
 *
 *  @param subMoudle Unity调用方法对应的SDKMoudle子类对象
 *
 *  @param requestClass 调用方法时对应的SDKRequest的子类名
 *
 *  @param responseClass 调用方法时对应的SDKResponse的子类名
 *
 *  @return 初始化后的SDKProtoRegisterInfo对象
 */
- (instancetype)initWithInterfaceName:(NSString *_Nullable)interfaceName method:(NSString *_Nullable)method moudle:(SDKMoudle *_Nullable)subMoudle requestClass:(NSString *_Nullable)requestClass responseClass:(NSString *_Nullable)responseClass;

/**
 *  调用SDKMoudle子类方法
 *
 *  @param requestContext 请求上下文对象
 */
- (void)callMoudleMethod:(SDKRequestContext *_Nullable)requestContext;

@end

NS_ASSUME_NONNULL_END
