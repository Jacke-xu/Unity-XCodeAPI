//
//  SDKReflection.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/14.
//

#import "SDKReflection.h"
#import "objc/runtime.h"
#import "MacroDefinition.h"

@implementation SDKReflection

+ (NSArray<NSString *> *)sharedSubClassFrom:(Class)superClass {
    NSMutableArray *results = [NSMutableArray array];
    int numClasses;
    Class *classes = NULL;
    numClasses = objc_getClassList(NULL,0);
    if (numClasses > 0) {
        classes = (__unsafe_unretained Class *)malloc(sizeof(Class) * numClasses);
        numClasses = objc_getClassList(classes, numClasses);
        for (int i = 0; i < numClasses; i++) {
            if (class_getSuperclass(classes[i]) == superClass) {
                [results addObject:NSStringFromClass(classes[i])];
            }
        }
        free(classes);
    }
    return [results copy];
}

+ (NSArray<NSString *> *)sharedClassMethodFrom:(NSString *)className {
    unsigned int count;
    Method *methodList = class_copyMethodList([NSClassFromString(className) class], &count);
    NSMutableArray <NSString *>*methods = [NSMutableArray array];
    for(unsigned int i = 0; i < count; i++){
        Method method = methodList[i];
        SEL _Nonnull aSelector = method_getName(method);
        NSString *methodName = NSStringFromSelector(aSelector);
        [methods addObject:methodName];
    }
    free(methodList);
    return [methods copy];
}

+ (NSString *)dictionaryToJson:(NSDictionary *)dictionary {
    
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:NSJSONWritingPrettyPrinted error:&parseError];
    if (parseError != nil) {
        NSLog(@"parseError = %@",parseError);
        return @"";
    }
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

+ (NSDictionary *)jsonToDictionary:(NSString *)json {
    
    NSData *jsonData = [json dataUsingEncoding:NSUTF8StringEncoding];
    NSError *parseError;
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&parseError];
    if (parseError != nil) {
        NSLog(@"parseError = %@",parseError);
        return @{};
    }
    return dictionary;
}

+ (NSArray<NSString *> *)sharedJsonDataKeys:(id)model {
    
    NSMutableArray <NSString *>*propertys = [NSMutableArray array];
    @autoreleasepool {
        // 遍历属性列表
        unsigned int outCount;
        objc_property_t *properties = class_copyPropertyList([model class], &outCount);
        for (unsigned int i = 0; i < outCount; i++) {
            // 获取属性的名字
            objc_property_t property = properties[i];
            const char *propertyName = property_getName(property);
            [propertys addObject:[[NSString alloc] initWithUTF8String:propertyName]];
        }
        free(properties);
    }
    return [propertys copy];
}

@end
