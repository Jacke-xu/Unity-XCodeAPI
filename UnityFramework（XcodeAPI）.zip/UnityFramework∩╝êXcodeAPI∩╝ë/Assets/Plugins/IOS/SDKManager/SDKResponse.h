//
//  SDKResponse.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import <Foundation/Foundation.h>
#import "JSONModelLib.h"

NS_ASSUME_NONNULL_BEGIN
@protocol SDKResponseProtocol <NSObject>
@end
@interface SDKResponse : JSONModel<SDKResponseProtocol>

/**
 *  回复unity的错误码
 */
@property (nonatomic, copy) NSString <Optional>*errorCode;

/**
 *  回复unity的错误描述信息
 */
@property (nonatomic, copy) NSString <Optional>*errorMessage;

@end

NS_ASSUME_NONNULL_END
