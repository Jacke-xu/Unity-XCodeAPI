//
//  SDKProtoManager.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import "SDKProtoManager.h"
#import "NSString+Extension.h"
#import "MacroDefinition.h"
#import "SDKProtoRegisterInfo.h"
#import "SDKMoudle.h"
#import "SDKResponseUnityConfig.h"

@implementation SDKProtoManager
singletonForImplementation(SDKProtoManager)

- (instancetype)init {
    if (self == [super init]) {
        if (_registerInfos == nil) {
            _registerInfos = [NSMutableDictionary dictionary];
        }
    }
    return self;
}

+ (void)regist:(NSString *)interfaceName method:(NSString * _Nullable)method moudle:(SDKMoudle * _Nullable)subMoudle requestClass:(NSString * _Nullable)requestClass responseClass:(NSString * _Nullable)responseClass {
    
    // 注册协议
    SDKProtoRegisterInfo *registerInfo = [[SDKProtoRegisterInfo alloc] initWithInterfaceName:interfaceName method:method moudle:subMoudle requestClass:requestClass responseClass:responseClass];
    
    if ([[SDKProtoManager shared].registerInfos.allKeys containsObject:registerInfo.interfaceName]) {
        return;
    }
    
    // 存储协议
    [[SDKProtoManager shared].registerInfos setValue:registerInfo forKey:registerInfo.interfaceName];
}

+ (void)invoke:(NSString *)interfaceName data:(NSString *)data {
    
    if ([NSString isEmptyStr:interfaceName]) {
        NSLog(@"interfaceName为空");
        [SDKRequestContext responseUnityWithEventId:[[SDKRequest alloc] initWithString:data error:nil].eventId data:[NSString stringWithFormat:@"{\"errorMessage\":\"InterfaceName is null\",\"errorCode\":\"%@\"}",SDKInterfaceNameIsNullCode]];
        return;
    }
    if (![[SDKProtoManager shared].registerInfos.allKeys containsObject:interfaceName]) {
        NSLog(@"registerInfos.allKeys不包含 %@ 这个interfaceName",interfaceName);
        [SDKRequestContext responseUnityWithEventId:[[SDKRequest alloc] initWithString:data error:nil].eventId data:[NSString stringWithFormat:@"{\"errorMessage\":\"%@ Interface name does not exist.\",\"errorCode\":\"%@\"}", interfaceName, SDKInterfaceNameIsNullCode]];
        return;
    }
    SDKProtoRegisterInfo *registerInfo = [[SDKProtoManager shared].registerInfos valueForKey:interfaceName];
    
    // 泛型处理SDKRequest子类
    NSError *error;
    SDKRequest *requestMoudle = [[NSClassFromString(registerInfo.requestClass) alloc] initWithString:data error:&error];
    if (error != nil) {
        NSLog(@"data转SDKRequest子类失败：data = %@, error = %@",data,error);
        [SDKRequestContext responseUnityWithEventId:[[SDKRequest alloc] initWithString:data error:nil].eventId data:[NSString stringWithFormat:@"{\"errorMessage\":\"JSON transform to SDKRequest error\",\"errorCode\":\"%@\"}", SDKJSONParseErrorCode]];
        return;
    }

    SDKRequestContext *requestContext = [[SDKRequestContext alloc] init];
    requestContext.request = requestMoudle;
    
    // 处理Unity向iOS发起的响应请求
    [registerInfo callMoudleMethod:requestContext];
}

+ (void)releaseAll {
    [[SDKProtoManager shared].registerInfos removeAllObjects];
}

@end
