//
//  SDKResponseUnityConfig.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/8.
//

#import <Foundation/Foundation.h>

/**
 *  响应Unity网络请求时成功errorMessage
 */
#define SDKSuccessErrorMessage     @""

/**
 *  响应Unity网络请求时成功Code
 */
#define SDKSuccessCode     @"0"

/**
 *  响应Unity网络请求时JSON解析失败Code
 */
#define SDKJSONParseErrorCode    @"1"

/**
 *  Unity传递过来的接口名为空时Code
 */
#define SDKInterfaceNameIsNullCode    @"2"
