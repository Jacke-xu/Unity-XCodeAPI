//
//  SDKProtoManager.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/7.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"
@class SDKProtoRegisterInfo, SDKMoudle;

NS_ASSUME_NONNULL_BEGIN

@interface SDKProtoManager : NSObject
singletonForInterface(SDKProtoManager)

/**
 *  SDK协议管理容器
 */
@property (nonatomic, strong) NSMutableDictionary <NSString *, SDKProtoRegisterInfo *>*registerInfos;

/**
 *  协议绑定
 *
 *  @param interfaceName 要绑定的协议名
 *
 *  @param method 要绑定的协议对应的方法
 *
 *  @param subMoudle interfaceName对应的SDKMoudle的子类对象
 *
 *  @param requestClass 调用方法时对应的SDKRequest的子类名
 *
 *  @param responseClass 调用方法时对应的SDKResponse的子类名
 */
+ (void)regist:(NSString *_Nullable)interfaceName method:(NSString *_Nullable)method moudle:(SDKMoudle *_Nullable)subMoudle requestClass:(NSString *_Nullable)requestClass responseClass:(NSString *_Nullable)responseClass;

/**
 *  SDK协议调度
 *
 *  @param interfaceName 要调用的协议名
 *
 *  @param data unity传递过来的消息
 */
+ (void)invoke:(NSString *_Nullable)interfaceName data:(NSString *_Nullable)data;

/**
 *  释放所有协议
 */
+ (void)releaseAll;

@end

NS_ASSUME_NONNULL_END
