//
//  UserMoudle.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/10.
//

#import "SDKMoudle.h"
#import "UserRequest.h"
#import "UserResponse.h"
#import "SDKRequestContext.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserMoudle : SDKMoudle

/**
 *  Unity要调用的方法
 *  @param  context 发起请求的上下文
 */
- (void)unityRequestDataWithUser:(SDKRequestContext <UserRequest *, UserResponse *> *)context;

@end

NS_ASSUME_NONNULL_END
