//
//  UserResponse.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/16.
//

#import "UserResponse.h"

@implementation UserResponse

+ (NSString *)sharedClassName {
    return NSStringFromClass([self class]);
}

@end
