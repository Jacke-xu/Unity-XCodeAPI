//
//  UserRequest.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/14.
//

#import "SDKRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserRequest : SDKRequest

/**
 *  测试字段
 */
@property (nonatomic, copy) NSString <Optional>*userData;

/**
 *  获取当前类名
 */
+ (NSString *)sharedClassName;

@end

NS_ASSUME_NONNULL_END
