//
//  UserMoudle.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/10.
//

#import "UserMoudle.h"
#import "SDKProtoManager.h"
#import "SDKResponseUnityConfig.h"

@implementation UserMoudle

- (void)initialization {
    
    [SDKProtoManager regist:@"unityRequestDataWithUser" method:@"unityRequestDataWithUser:" moudle:self requestClass:[UserRequest sharedClassName] responseClass:[UserResponse sharedClassName]];
}

- (void)unityRequestDataWithUser:(SDKRequestContext<UserRequest *,UserResponse *> *)context {
    
    UserResponse *response = [[UserResponse alloc] init];
    response.errorCode = SDKSuccessCode;
    response.errorMessage = SDKSuccessErrorMessage;
    response.other = @"otherValue";
    [context setResponse:response];
}

@end
