//
//  UserResponse.h
//  UnityFramework
//
//  Created by zhanxun on 2024/5/16.
//

#import "SDKResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserResponse : SDKResponse

/**
 *  其他可能需要的字段，具体看需求
 */
@property (nonatomic, copy) NSString *other;

/**
 *  获取当前类名
 */
+ (NSString *)sharedClassName;

@end

NS_ASSUME_NONNULL_END
