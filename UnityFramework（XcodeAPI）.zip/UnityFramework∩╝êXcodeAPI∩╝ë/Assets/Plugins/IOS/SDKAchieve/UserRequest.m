//
//  UserRequest.m
//  UnityFramework
//
//  Created by zhanxun on 2024/5/14.
//

#import "UserRequest.h"

@implementation UserRequest

+ (NSString *)sharedClassName {
    return NSStringFromClass([self class]);
}

@end
