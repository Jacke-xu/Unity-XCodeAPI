﻿using UnityEngine;

namespace YoYo.Unity.SDK.Moudles
{
    //用户
    public class Test : MonoBehaviour
    {
        SDKManager sdkManager;

        private void Awake()
        {
            sdkManager = SDKManager.Instance;
            sdkManager.Register(new TestModule());
            //sdkManager.Register(new RealizeAndroidNotifcation());
        }

        public void notif()
        {
            TestModule.Init(response =>
            {
                if(response.IsSuccess)
                {
                    Debug.Log("接收iOS成功回调:"+response);
                }
                else
                {
                    Debug.Log("接收iOS异常回调:"+response);
                }
            });
        }
    }
}
