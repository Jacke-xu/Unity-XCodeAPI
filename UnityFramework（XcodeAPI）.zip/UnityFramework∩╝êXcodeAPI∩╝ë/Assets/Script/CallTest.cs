using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using UnityEngine;

public class CallTest : MonoBehaviour
{
    [DllImport("__Internal")]
    private static extern void CallSync(string interfaceName, string data);

    public static void SendMessageToIOS(string interfaceName, string data) {
#if UNITY_IOS
        Debug.Log("向iOS发出消息\ninterfaceName = " + interfaceName + "\ndata = " + data + "\n");
        CallSync(interfaceName, data);
#endif
    }
}
