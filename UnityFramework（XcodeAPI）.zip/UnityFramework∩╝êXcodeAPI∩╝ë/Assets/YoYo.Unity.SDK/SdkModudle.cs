﻿using UnityEngine;

namespace YoYo.Unity.SDK.Moudles
{
    /// <summary>
    /// SDK模块
    /// </summary>
    public abstract class SdkModudle 
    {
        #region Properties
#if UNITY_ANDROID
        private static AndroidJavaObject currentActivity;

        /// <summary>
        /// 当前Unity所在的Activity窗口
        /// </summary>
        protected static AndroidJavaObject CurrentActivity
        {
            get
            {
                if(currentActivity == null)
                {
                    AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                    currentActivity = jc.GetStatic<AndroidJavaObject>("currentActivity");
                }

                return currentActivity;
            }
        }
#endif
        #endregion

        #region Internal Methods
        /// <summary>
        /// 初始化
        /// </summary>
        protected abstract internal void Initialize();

        /// <summary>
        /// 
        /// </summary>
        protected abstract internal void Release();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="interfaceRegister"></param>
        protected abstract internal void BindSDKInterface(SDKInterfaceRegiseter interfaceRegister);

        /// <summary>
        /// 同步调用SDK方法
        /// </summary>
        /// <typeparam name="TSDKResponse"><see cref="TSDKResponse"/></typeparam>
        /// <param name="interfaceName">接口名</param>
        /// <param name="request"><see cref="SDKRequest"/></param>
        /// <returns>返回调用结果<see cref="SDKResponse"/></returns>
        protected TSDKResponse Call<TSDKResponse>(string interfaceName, SDKRequest request) where TSDKResponse : SDKResponse
        {
            string content = JsonUtility.ToJson(request);
            Debug.LogFormat("CallSync:{0},Args:{1}", interfaceName, content);
#if UNITY_IOS
            CallTest.SendMessageToIOS(interfaceName, content);
#endif
#if UNITY_ANDROID
            string jsonResult = CurrentActivity.Call<string>("CallSync", interfaceName, content);

            return JsonUtility.FromJson<TSDKResponse>(jsonResult);
#else
            return default;
#endif

        }

        /// <summary>
        /// 异步调用SDK方法
        /// </summary>
        /// <param name="interfaceName">接口名</param>
        /// <param name="request"><see cref="SDKRequest"/></param>
        protected void CallAsync(string interfaceName, SDKRequest request)
        {
            string content = JsonUtility.ToJson(request);
            Debug.LogFormat("CallASync:{0},Args:{1}", interfaceName, content);
#if UNITY_ANDROID
            CurrentActivity.Call("CallSync", interfaceName, content);
#endif
        }
        #endregion
    }

}
