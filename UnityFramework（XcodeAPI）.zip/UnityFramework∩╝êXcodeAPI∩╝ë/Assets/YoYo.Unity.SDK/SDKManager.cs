﻿using System;
using System.Collections.Generic;
using UnityEngine;
using YoYo.Unity.SDK.Moudles;

namespace YoYo.Unity.SDK
{
    /// <summary>
    /// SDK管理器
    /// </summary>
    public class SDKManager : MonoBehaviour, SDKInterfaceRegiseter
    {
        private static SDKManager instance;

        private List<SdkModudle> modules = new List<SdkModudle>();
        private Dictionary<string, Func<SDKRequest, SDKResponse>> interfaceMap = new ();

        private Dictionary<string, KeyValuePair<Action<SDKRequest>, Type>> interfaceMapAsyncMap = new ();
        private Dictionary<int, KeyValuePair<Type, Action<SDKResponse>>> waitPlatformCallbackDict = new ();
        private int eventId;

        /// <summary>
        /// SDK管理器单例
        /// </summary>
        public static SDKManager Instance
        {
            get
            {
                if (instance == null)
                {
                    GameObject go = new GameObject(nameof(SDKManager));
                    instance = go.AddComponent<SDKManager>();
                }
                return instance;
            }
        }

        #region Public Methods
        public void Register(SdkModudle module)
        {
            modules.Add(module);
            module.Initialize();
            module.BindSDKInterface(this);
        }

        /// <summary>
        /// 调用SDK方法
        /// </summary>
        /// <typeparam name="TSDKResponse">返回值类型</typeparam>
        /// <param name="interfaceName">接口名</param>
        /// <param name="request">请求参数</param>
        /// <returns>返回<see cref="TSDKResponse"/></returns>
        public TSDKResponse Call<TSDKResponse>(string interfaceName, SDKRequest request) where TSDKResponse : SDKResponse
        {
            if (interfaceMap.TryGetValue(interfaceName, out var func))
            {
                return func(request) as TSDKResponse;
            }

            return null;
        }

        /// <summary>
        /// 调用SDK方法
        /// </summary>
        /// <param name="interfaceName">接口名</param>
        /// <param name="request">请求参数</param>
        public void Call(string interfaceName, SDKRequest request)
        {
            if (interfaceMap.TryGetValue(interfaceName, out var func))
            {
                func(request);
            }
        }

        /// <summary>
        /// 调用SDK方法
        /// </summary>
        /// <typeparam name="TSDKResponse">返回值类型</typeparam>
        /// <param name="interfaceName">接口名</param>
        /// <param name="request">请求参数</param>
        /// <param name="callback">请求完成回调</param>
        /// <returns>返回<see cref="TSDKResponse"/></returns>
        public void Call<TSDKResponse>(string interfaceName, SDKRequest request, Action<TSDKResponse> callback) where TSDKResponse : SDKResponse
        {
            if (interfaceMapAsyncMap.TryGetValue(interfaceName, out var pair))
            {
                int id = ++eventId;
                request.eventId = id;
                pair.Key(request);
                waitPlatformCallbackDict.Add(id, new KeyValuePair<Type, Action<SDKResponse>>(pair.Value, response =>
                {
                    callback((TSDKResponse)response);
                }));
            }
        }
        #endregion

        #region Internal Methods
        /// <summary>
        /// SDK异步回调到此方法,标准格式为:1:{"ErrorCode":0, "Error": "错误提示内容"}
        /// </summary>
        /// <param name="data"></param>
        private void OnPlatformCall(string data)
        {
            try
            {
                int index = data.IndexOf(":");
                int eventId = int.Parse(data.Substring(0, index));
                if (waitPlatformCallbackDict.TryGetValue(eventId, out var pair))
                {
                    string content = data.Substring(index + 1);
                    SDKResponse response =(SDKResponse)JsonUtility.FromJson(content, pair.Key);
                    pair.Value(response);
                }
            }
            catch(Exception e)
            {
                Debug.LogErrorFormat("平台回调处理错误:{0}\n{1}", data, e);
            }
        }

        /// <summary>
        /// Unity脚本销毁
        /// </summary>
        private void OnDestroy()
        {
            foreach (var adapter in modules)
            {
                adapter.Release();
            }
            modules.Clear();
        }
        #endregion

        #region SDKInterfaceRegiseter Implements
        /// <inheritdoc/>
        void SDKInterfaceRegiseter.Regist<TRequest, TResponse>(string interfaceName, Func<TRequest, TResponse> impFunc)
        {
            interfaceMap.Add(interfaceName, request => {
                return impFunc((TRequest)request);
            });
        }

        /// <inheritdoc/>
        void SDKInterfaceRegiseter.Regist<TRequest>(string interfaceName, Action<TRequest> impFunc)
        {
            interfaceMap.Add(interfaceName, request => {
                impFunc((TRequest)request);
                return null;
            });
        }



        /// <inheritdoc/>
        void SDKInterfaceRegiseter.Regist<TRequest, TResponse>(string interfaceName, Action<TRequest> impFunc)
        {
            interfaceMapAsyncMap.Add(interfaceName, new KeyValuePair<Action<SDKRequest>, Type>(request =>
            {
                impFunc((TRequest)request);
            }, typeof(TResponse)));
        }

      
        #endregion
    }
}
