using UnityEngine;

namespace YoYo.Unity.SDK
{
    /// <summary>
    /// SDK请求参数
    /// </summary>
    public class SDKRequest
    {
        #region Properties
        /// <summary>
        /// 事件id
        /// </summary>
        [SerializeField]
        internal int eventId;
        #endregion
    }
}