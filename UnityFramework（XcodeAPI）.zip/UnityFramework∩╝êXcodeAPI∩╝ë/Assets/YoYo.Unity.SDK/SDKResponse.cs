using System;
using UnityEngine;

namespace YoYo.Unity.SDK
{
    /// <summary>
    /// SDK数据反馈
    /// </summary>
    [Serializable]
    public class SDKResponse
    {
        #region Properties
        /// <summary>
        /// 错误码，0为成功，其它为失败
        /// </summary>
        [SerializeField]
        private int errorCode;

        /// <summary>
        /// 错误提示内容
        /// </summary>
        [SerializeField]
        private string errorMesssage;

        /// <summary>
        /// 默认成功的返回
        /// </summary>
        public readonly static SDKResponse SuccessResponse = new SDKResponse();
        
       

        /// <summary>
        /// 是否为成功返回
        /// </summary>
        public bool IsSuccess => ErrorCode == 0;

        /// <summary>
        /// 是否为失败返回
        /// </summary>
        public bool IsFailed => !IsSuccess;

        /// <summary>
        /// 错误码，0为成功，其它为失败
        /// </summary>
        public int ErrorCode => errorCode;

        /// <summary>
        /// 错误提示内容
        /// </summary>
        public string ErrorMesssage => errorMesssage;
        #endregion

        #region Constructors
        /// <summary>
        /// 构造
        /// </summary>
        public SDKResponse()
        {

        }

        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="errorCode">错误码，0为成功，其它为失败</param>
        /// <param name="errorMesssage">错误提示内容</param>
        public SDKResponse(int errorCode, string errorMesssage)
        {
            this.errorCode = errorCode;
            this.errorMesssage = errorMesssage;
        }
        #endregion
    }
}
