
using System;
using UnityEngine;

namespace YoYo.Unity.SDK.Moudles
{
    public class TestModule : SdkModudle
    {
        protected internal override void BindSDKInterface(SDKInterfaceRegiseter interfaceRegister)
        {
            interfaceRegister.Regist<SDKRequest, SDKResponse>(nameof(OnInit), OnInit);
        }

        protected internal override void Initialize()
        {

        }

        protected internal override void Release()
        {

        }

        private void OnInit(SDKRequest request)
        {
            var value = Call<SDKResponse>("unityRequestDataWithUser", request);
        }

        public static void Init(Action<SDKResponse> callback)
        {
            SDKManager.Instance.Call(nameof(OnInit), new SDKRequest(), callback);
        }
    }
}

