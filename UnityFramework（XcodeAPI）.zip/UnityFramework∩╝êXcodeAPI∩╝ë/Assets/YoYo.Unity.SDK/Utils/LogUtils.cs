﻿using UnityEngine;

namespace YoYo.Unity.SDK.Moudles
{
    #region
    /// <summary>
    ///  Logs a formatted error message to the Unity console
    /// </summary>
    public class LogUtils
    {
        #region error
        /// <summary>
        /// Logs a formatted error message to the Unity console
        /// </summary>
        /// <param name="message">message contect</param>
        public static void LogErrorFormat(object message)
        {
            Debug.LogErrorFormat(message + " can not be empty");
        }

        /// <summary>
        /// Logs a formatted error message to the Unity console
        /// </summary>
        /// <param name="message">message contect</param>
        public static void LogError(object message)
        {
            Debug.LogError(message+ " can not be empty");
        }
        #endregion
    }
    #endregion
}
