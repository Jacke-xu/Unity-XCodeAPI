using System;
using YoYo.Unity.SDK;

/// <summary>
/// SDK接口注册器
/// </summary>
public interface SDKInterfaceRegiseter 
{
    #region Methods
    /// <summary>
    /// 注册SDK接口同步实现
    /// </summary>
    /// <typeparam name="TRequest">请求参数</typeparam>
    /// <typeparam name="TResponse">返回参数</typeparam>
    /// <param name="interfaceName">接口名</param>
    /// <param name="impFunc">实现方法</param>
    void Regist<TRequest, TResponse>(string interfaceName, Func<TRequest, TResponse> impFunc)
        where TRequest : SDKRequest
        where TResponse : SDKResponse, new();

    /// <summary>
    /// 注册SDK接口同步实现,不带返回值
    /// </summary>
    /// <typeparam name="TRequest">请求参数</typeparam>
    /// <typeparam name="TResponse">返回参数</typeparam>
    /// <param name="interfaceName">接口名</param>
    /// <param name="impFunc">实现方法</param>
    void Regist<TRequest>(string interfaceName, Action<TRequest> impFunc)
        where TRequest : SDKRequest;

    /// <summary>
    /// 注册SDK接口异步实现
    /// </summary>
    /// <typeparam name="TRequest">请求参数</typeparam>
    /// <typeparam name="TResponse">返回参数</typeparam>
    /// <param name="interfaceName">接口名</param>
    /// <param name="impFunc">实现方法</param>
    void Regist<TRequest, TResponse>(string interfaceName, Action<TRequest> impFunc)
        where TRequest : SDKRequest
        where TResponse : SDKResponse, new();

    #endregion
}
